"""Observation-to-parameter calibration."""

