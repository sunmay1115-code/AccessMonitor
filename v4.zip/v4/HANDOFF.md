# Collusim v4 Handoff

## Current State

V4 no longer uses RiskLab, Ollama, local model probes, local fingerprints, or
proxy fallback validation.

The dashboard has exactly two tabs:

1. **The Problem:** fixed empirical findings from teammate E3 and E4.
2. **The Solution:** Collusim's restriction frontier and objective ranking.

## Retained Components

- `src/detection/cmi_wrapper.py` is the detector and remains unchanged.
- `src/collusim/environment.py` and `src/collusim/agents.py` remain unchanged.
- `src/collusim/experiments.py` remains unchanged.
- `src/collusim/objectives.py` remains unchanged.
- The randomized Collusim RCT and evidence ranking remain unchanged.

## Removed Components

- RiskLab source and dependency installation.
- Ollama client and local probe pipeline.
- Local fingerprint dashboard.
- RiskLab validation results and fallback banner.
- Removed validation tests and entry points.

## Run

```bash
python -m pip install -r requirements.txt
python run_v4_pipeline.py
streamlit run app.py
```

`run_v4_pipeline.py` rebuilds scripted detector evidence, the Collusim RCT, and
the objective analysis. It never calls a model provider.

## Current Result

Noise injection at precision-loss strength `0.40` remains the selected
restriction:

- markup reduction: `74.0%`;
- CMI reduction: `85.4%`;
- welfare effect: `0.53%` improvement;
- efficiency ratio: `0.248`.

## Verification

```bash
python -m pytest tests -q
```

The retained CMI wrapper, Collusim experiment code, and objective ranking are
hash-checked after this cleanup.
