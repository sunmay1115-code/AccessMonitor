"""Predictive learning, SHAP, learning curves, and calibration."""

from __future__ import annotations

import json

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import shap
from sklearn.base import clone
from sklearn.dummy import DummyClassifier, DummyRegressor
from sklearn.ensemble import (
    HistGradientBoostingClassifier,
    HistGradientBoostingRegressor,
    RandomForestClassifier,
    RandomForestRegressor,
)
from sklearn.linear_model import LogisticRegression, Ridge
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    r2_score,
)
from sklearn.model_selection import (
    GridSearchCV,
    KFold,
    StratifiedKFold,
    learning_curve,
)

from config import (
    CI_LEVEL,
    FEATURES,
    FIGURES_DIR,
    MODELS,
    N_BOOTSTRAP,
    RESULTS_DIR,
    SEED,
)
from deferred.llm_track.common import bootstrap_ci, load_behavior, make_split


def _classification_matrix(frame: pd.DataFrame) -> np.ndarray:
    model_dummy = (frame["model_name"] == MODELS[1]).astype(float).to_numpy()
    return np.column_stack(
        [frame[feature].to_numpy(dtype=float) for feature in FEATURES]
        + [model_dummy]
    )


def _bootstrap_metric(
    y_true: np.ndarray,
    predictions: np.ndarray,
    metric,
) -> tuple[float, float, float]:
    indices = np.arange(len(y_true))
    rng = np.random.default_rng(SEED)
    values = []
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(indices, size=len(indices), replace=True)
        values.append(metric(y_true[draw], predictions[draw]))
    _, low, high = bootstrap_ci(values, n_boot=N_BOOTSTRAP, ci=CI_LEVEL)
    return float(metric(y_true, predictions)), low, high


def _nested_model(
    task: str,
    model_name: str,
    estimator,
    parameters: dict,
    x_train: np.ndarray,
    y_train: np.ndarray,
    x_test: np.ndarray,
    y_test: np.ndarray,
    scoring: str,
) -> tuple[dict, object]:
    if task == "classification":
        outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    else:
        outer = KFold(n_splits=5, shuffle=True, random_state=SEED)
    outer_scores = []
    for train_index, validation_index in outer.split(x_train, y_train):
        search = GridSearchCV(
            clone(estimator),
            parameters,
            cv=3,
            scoring=scoring,
            n_jobs=-1,
        )
        search.fit(x_train[train_index], y_train[train_index])
        predicted = search.predict(x_train[validation_index])
        if task == "classification":
            outer_scores.append(
                f1_score(
                    y_train[validation_index],
                    predicted,
                    average="macro",
                )
            )
        else:
            outer_scores.append(r2_score(y_train[validation_index], predicted))

    final_search = GridSearchCV(
        clone(estimator),
        parameters,
        cv=3,
        scoring=scoring,
        n_jobs=-1,
    )
    final_search.fit(x_train, y_train)
    predictions = final_search.predict(x_test)
    if task == "classification":
        metric = lambda truth, pred: f1_score(
            truth, pred, average="macro", zero_division=0
        )
        test_score, low, high = _bootstrap_metric(y_test, predictions, metric)
        actual_metric = "macro_f1"
        secondary_metric = float(accuracy_score(y_test, predictions))
        confusion = confusion_matrix(y_test, predictions).tolist()
    else:
        metric = r2_score
        test_score, low, high = _bootstrap_metric(y_test, predictions, metric)
        actual_metric = "r2"
        secondary_metric = float(mean_absolute_error(y_test, predictions))
        confusion = None
    return (
        {
            "task": task,
            "model": model_name,
            "metric_name": actual_metric,
            "test_metric": test_score,
            "test_ci_low": low,
            "test_ci_high": high,
            "secondary_metric": secondary_metric,
            "confusion_matrix": (
                None if confusion is None else json.dumps(confusion)
            ),
            "cv_mean": float(np.mean(outer_scores)),
            "cv_std": float(np.std(outer_scores, ddof=1)),
            "best_params": json.dumps(final_search.best_params_, sort_keys=True),
        },
        final_search.best_estimator_,
    )


def model_ladder() -> pd.DataFrame:
    """Fit baseline, linear, tree, and boosted models on both tasks."""

    frame = load_behavior()
    train, test = make_split(frame)
    x_train = _classification_matrix(train)
    x_test = _classification_matrix(test)
    rows = []
    classification_y_train = train["strategy"].to_numpy()
    classification_y_test = test["strategy"].to_numpy()
    regression_y_train = train["llm_price"].to_numpy(dtype=float)
    regression_y_test = test["llm_price"].to_numpy(dtype=float)

    classification_models = [
        (
            "baseline",
            DummyClassifier(strategy="most_frequent"),
            {},
        ),
        (
            "linear",
            LogisticRegression(
                max_iter=5_000,
                class_weight="balanced",
                random_state=SEED,
            ),
            {"C": [0.1, 1.0, 10.0]},
        ),
        (
            "tree_ensemble",
            RandomForestClassifier(
                n_estimators=150,
                random_state=SEED,
                n_jobs=-1,
            ),
            {"max_depth": [None, 6], "min_samples_leaf": [1, 5]},
        ),
        (
            "boosted",
            HistGradientBoostingClassifier(
                random_state=SEED,
                early_stopping=False,
            ),
            {"learning_rate": [0.05, 0.1], "max_depth": [2, 4]},
        ),
    ]
    for name, model, params in classification_models:
        row, _ = _nested_model(
            "classification",
            name,
            model,
            params,
            x_train,
            classification_y_train,
            x_test,
            classification_y_test,
            "f1_macro",
        )
        rows.append(row)

    regression_models = [
        ("baseline", DummyRegressor(strategy="mean"), {}),
        (
            "linear",
            Ridge(),
            {"alpha": [0.1, 1.0, 10.0, 100.0]},
        ),
        (
            "tree_ensemble",
            RandomForestRegressor(
                n_estimators=150,
                random_state=SEED,
                n_jobs=-1,
            ),
            {"max_depth": [None, 6], "min_samples_leaf": [1, 5]},
        ),
        (
            "boosted",
            HistGradientBoostingRegressor(
                random_state=SEED,
                early_stopping=False,
            ),
            {"learning_rate": [0.05, 0.1], "max_depth": [2, 4]},
        ),
    ]
    for name, model, params in regression_models:
        row, _ = _nested_model(
            "regression",
            name,
            model,
            params,
            x_train,
            regression_y_train,
            x_test,
            regression_y_test,
            "r2",
        )
        rows.append(row)

    result = pd.DataFrame(rows)
    result.to_csv(RESULTS_DIR / "model_comparison.csv", index=False)
    return result


def _fit_tree_regressor() -> tuple[RandomForestRegressor, np.ndarray, np.ndarray]:
    frame = load_behavior()
    train, test = make_split(frame)
    x_train = _classification_matrix(train)
    x_test = _classification_matrix(test)
    y_train = train["llm_price"].to_numpy(dtype=float)
    model = RandomForestRegressor(
        n_estimators=300,
        min_samples_leaf=3,
        random_state=SEED,
        n_jobs=-1,
    )
    model.fit(x_train, y_train)
    return model, x_train, x_test


def shap_importance() -> pd.DataFrame:
    """Compute TreeSHAP importance for the price model."""

    model, x_train, x_test = _fit_tree_regressor()
    try:
        explainer = shap.TreeExplainer(
            model,
            data=x_train,
            feature_perturbation="tree_path_dependent",
            max_samples=len(x_train),
        )
    except (TypeError, ValueError):
        explainer = shap.TreeExplainer(model)
    values = np.asarray(explainer.shap_values(x_test))
    if values.ndim == 3:
        values = values.mean(axis=2)
    names = [*FEATURES, "model_is_qwen"]
    frame = pd.DataFrame(
        {
            "model_name": "random_forest_price",
            "feature": names,
            "mean_abs_shap": np.abs(values).mean(axis=0),
        }
    )
    frame["rank"] = frame["mean_abs_shap"].rank(
        method="first",
        ascending=False,
    ).astype(int)
    frame = frame.sort_values("rank")
    frame.to_csv(RESULTS_DIR / "shap_importance.csv", index=False)

    shap.summary_plot(values, x_test, feature_names=names, show=False)
    plt.tight_layout()
    plt.savefig(FIGURES_DIR / "shap_summary.png", dpi=180)
    plt.close()
    return frame


def learning_curves() -> pd.DataFrame:
    """Write eight-point learning curves for the linear and boosted models."""

    frame = load_behavior()
    train, _ = make_split(frame)
    x = _classification_matrix(train)
    y = train["strategy"].to_numpy()
    models = {
        "linear": LogisticRegression(
            max_iter=5_000,
            class_weight="balanced",
            C=1.0,
            random_state=SEED,
        ),
        "boosted": HistGradientBoostingClassifier(
            learning_rate=0.1,
            max_depth=3,
            early_stopping=False,
            random_state=SEED,
        ),
    }
    rows = []
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
    sizes = np.linspace(0.1, 1.0, 8)
    for model_name, model in models.items():
        train_sizes, train_scores, cv_scores = learning_curve(
            model,
            x,
            y,
            train_sizes=sizes,
            cv=cv,
            scoring="f1_macro",
            n_jobs=-1,
            shuffle=True,
            random_state=SEED,
        )
        frame_rows = pd.DataFrame(
            {
                "model": model_name,
                "train_size": train_sizes,
                "train_score": train_scores.mean(axis=1),
                "cv_score_mean": cv_scores.mean(axis=1),
                "cv_score_std": cv_scores.std(axis=1, ddof=1),
            }
        )
        rows.append(frame_rows)

        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(
            frame_rows["train_size"],
            frame_rows["train_score"],
            marker="o",
            label="training score",
        )
        ax.plot(
            frame_rows["train_size"],
            frame_rows["cv_score_mean"],
            marker="o",
            label="cross-validation",
        )
        ax.fill_between(
            frame_rows["train_size"],
            frame_rows["cv_score_mean"] - frame_rows["cv_score_std"],
            frame_rows["cv_score_mean"] + frame_rows["cv_score_std"],
            alpha=0.15,
        )
        ax.set_xlabel("Training examples")
        ax.set_ylabel("Macro-F1")
        ax.set_title(f"Learning curve: {model_name}")
        ax.grid(alpha=0.2)
        ax.legend(frameon=False)
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / f"learning_curve_{model_name}.png", dpi=180)
        plt.close(fig)

    result = pd.concat(rows, ignore_index=True)
    result.to_csv(RESULTS_DIR / "learning_curves.csv", index=False)
    return result


def calibration() -> pd.DataFrame:
    """Write reliability data and Brier score for match prediction."""

    frame = load_behavior()
    train, test = make_split(frame)
    x_train = _classification_matrix(train)
    x_test = _classification_matrix(test)
    y_train = (train["strategy"] == "match").astype(int).to_numpy()
    y_test = (test["strategy"] == "match").astype(int).to_numpy()
    model = HistGradientBoostingClassifier(
        learning_rate=0.1,
        max_depth=3,
        early_stopping=False,
        random_state=SEED,
    )
    model.fit(x_train, y_train)
    probabilities = model.predict_proba(x_test)[:, 1]

    bins = pd.cut(
        probabilities,
        bins=np.linspace(0.0, 1.0, 11),
        include_lowest=True,
    )
    frame_cal = pd.DataFrame(
        {
            "probability": probabilities,
            "observed": y_test,
            "bin": bins,
        }
    )
    calibration_frame = (
        frame_cal.groupby("bin", observed=False)
        .agg(
            predicted_mean=("probability", "mean"),
            observed_freq=("observed", "mean"),
            n=("observed", "size"),
        )
        .reset_index()
    )
    calibration_frame = calibration_frame.loc[
        calibration_frame["n"] > 0
    ].reset_index(drop=True)
    calibration_frame["bin"] = np.arange(len(calibration_frame))
    calibration_frame.to_csv(RESULTS_DIR / "calibration.csv", index=False)

    brier = float(brier_score_loss(y_test, probabilities))
    indices = np.arange(len(y_test))
    rng = np.random.default_rng(SEED)
    values = []
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(indices, size=len(indices), replace=True)
        values.append(brier_score_loss(y_test[draw], probabilities[draw]))
    _, low, high = bootstrap_ci(values, ci=CI_LEVEL)
    (RESULTS_DIR / "calibration_summary.json").write_text(
        json.dumps(
            {
                "brier_score": brier,
                "brier_ci_low": low,
                "brier_ci_high": high,
                "n": len(y_test),
            },
            indent=2,
        ),
        encoding="ascii",
    )

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot([0, 1], [0, 1], linestyle="--", color="#64748B", label="perfect")
    ax.plot(
        calibration_frame["predicted_mean"],
        calibration_frame["observed_freq"],
        marker="o",
        color="#0F766E",
        label="model",
    )
    ax.set_xlabel("Predicted probability of match")
    ax.set_ylabel("Observed match frequency")
    ax.set_title("Reliability diagram")
    ax.grid(alpha=0.2)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(FIGURES_DIR / "reliability.png", dpi=180)
    plt.close(fig)
    return calibration_frame


if __name__ == "__main__":
    from deferred.llm_track.llm_behavior import run_synthetic_states

    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    if not (RESULTS_DIR / "llm_behavior.csv").exists():
        run_synthetic_states()
    comparison = model_ladder()
    print(comparison.to_string(index=False))
    classification = comparison.loc[comparison["task"] == "classification"]
    baseline = classification.loc[
        classification["model"] == "baseline", "test_metric"
    ].iloc[0]
    boosted = classification.loc[
        classification["model"] == "boosted", "test_metric"
    ].iloc[0]
    assert boosted > baseline
    shap_importance()
    learning_curves()
    calibration()
    print("Predictive-learning sanity check passed")
