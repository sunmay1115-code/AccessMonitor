"""Build and validate the synthetic market-response dataset."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from config import (
    DATA_DIR,
    EPSILON,
    FEATURES,
    MIN_ROWS_PER_MODEL,
    MODELS,
    N_STATES_TARGET,
    RESULTS_DIR,
    SEED,
    STRATEGIES,
)
from deferred.llm_track.common import derive_strategy, generate_states


DATASET_VERSION = "1.0"
RAW_DATASET_PATH = DATA_DIR / "llm_behavior_raw.csv"
ANALYSIS_DATASET_PATH = RESULTS_DIR / "llm_behavior.csv"
FAILURES_PATH = RESULTS_DIR / "llm_behavior_failures.csv"
MANIFEST_PATH = RESULTS_DIR / "dataset_manifest.json"
DATASET_CARD_PATH = RESULTS_DIR / "dataset_card.md"
SYNTHETIC_TEMPERATURE = 0.2


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _prompt(state: pd.Series, model_name: str) -> str:
    del model_name
    return (
        "You are pricing one product. Choose a price between 1.0 and 3.0 "
        "that maximizes cumulative profit across repeated rounds. You cannot "
        "communicate with competitors.\n"
        f"Current round: {state['round_norm']:.3f}.\n"
        f"Your previous price: {state['own_price']:.2f}.\n"
        f"Competitor previous price: {state['competitor_price']:.2f}.\n"
        f"Current demand signal: {state['demand']:.2f}.\n"
        f"Lagged demand: {state['lagged_demand']:.2f}.\n"
        f"Market average price: {state['market_mean_price']:.2f}.\n"
        'Return JSON only: {"price": <number>, "rationale": "<one sentence>"}.'
    )


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _dataset_row(
    state: pd.Series,
    model_name: str,
    run_id: str,
    collected_at: str,
    prompt: str,
    price: float | None,
    rationale: str,
    raw_output: str,
    error: str,
    attempt_count: int,
    data_source: str,
) -> dict:
    valid = price is not None and np.isfinite(price) and 1.0 <= price <= 3.0
    strategy = (
        derive_strategy(
            float(price),
            float(state["competitor_price"]),
            epsilon=EPSILON,
        )
        if valid
        else ""
    )
    return {
        "dataset_version": DATASET_VERSION,
        "run_id": run_id,
        "row_id": f"{run_id}:{model_name}:{int(state['state_id'])}",
        "collected_at": collected_at,
        "data_source": data_source,
        "model_name": model_name,
        "state_id": int(state["state_id"]),
        **{feature: float(state[feature]) for feature in FEATURES},
        "prompt": prompt,
        "prompt_sha256": _hash_text(prompt),
        "temperature": SYNTHETIC_TEMPERATURE,
        "attempt_count": int(attempt_count),
        "raw_output": raw_output,
        "llm_price": float(price) if valid else np.nan,
        "rationale": rationale,
        "strategy": strategy,
        "is_valid": bool(valid),
        "collection_error": error,
    }


def validate_dataset(
    frame: pd.DataFrame,
    enforce_sample_size: bool = True,
) -> dict:
    """Validate schema, uniqueness, labels, and sample size."""

    required = {
        "dataset_version",
        "run_id",
        "row_id",
        "model_name",
        "state_id",
        *FEATURES,
        "prompt",
        "prompt_sha256",
        "raw_output",
        "llm_price",
        "strategy",
        "is_valid",
        "data_source",
    }
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Dataset missing columns: {sorted(missing)}")
    duplicates = int(frame.duplicated(["model_name", "state_id"]).sum())
    valid = frame.loc[frame["is_valid"]].copy()
    invalid_labels = valid.loc[~valid["strategy"].isin(STRATEGIES)]
    out_of_range = valid.loc[~valid["llm_price"].between(1.0, 3.0)]
    mismatched = valid.apply(
        lambda row: derive_strategy(
            float(row["llm_price"]),
            float(row["competitor_price"]),
            EPSILON,
        )
        != row["strategy"],
        axis=1,
    )
    counts = valid.groupby("model_name").size().to_dict()
    sample_ok = all(counts.get(model, 0) >= MIN_ROWS_PER_MODEL for model in MODELS)
    report = {
        "schema_ok": True,
        "duplicate_model_state_pairs": duplicates,
        "invalid_label_rows": int(len(invalid_labels)),
        "price_out_of_range_rows": int(len(out_of_range)),
        "strategy_mismatch_rows": int(mismatched.sum()),
        "valid_rows_by_model": counts,
        "sample_size_ok": bool(sample_ok),
    }
    if duplicates or len(invalid_labels) or len(out_of_range) or mismatched.any():
        raise ValueError(f"Dataset validation failed: {report}")
    if enforce_sample_size and not sample_ok:
        raise ValueError(
            f"Valid rows per model below {MIN_ROWS_PER_MODEL}: {counts}"
        )
    return report


def _write_dataset_artifacts(
    frame: pd.DataFrame,
    run_id: str,
    data_source: str,
    n_states_requested: int,
    enforce_sample_size: bool = True,
) -> dict:
    """Write raw, analysis-ready, failure, manifest, and card artifacts."""

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    frame.to_csv(RAW_DATASET_PATH, index=False)
    valid = frame.loc[frame["is_valid"]].reset_index(drop=True)
    failures = frame.loc[~frame["is_valid"]].reset_index(drop=True)
    valid.to_csv(ANALYSIS_DATASET_PATH, index=False)
    failures.to_csv(FAILURES_PATH, index=False)
    validation = validate_dataset(
        frame,
        enforce_sample_size=enforce_sample_size,
    )
    class_counts = (
        valid.groupby(["model_name", "strategy"])
        .size()
        .unstack(fill_value=0)
        .to_dict(orient="index")
    )
    prompt_hashes = sorted(frame["prompt_sha256"].unique().tolist())
    manifest = {
        "dataset_version": DATASET_VERSION,
        "run_id": run_id,
        "created_at": _utc_now(),
        "data_source": data_source,
        "models": sorted(frame["model_name"].unique().tolist()),
        "n_states_requested": int(n_states_requested),
        "rows_raw": int(len(frame)),
        "rows_valid": int(len(valid)),
        "rows_failed": int(len(failures)),
        "valid_rows_by_model": validation["valid_rows_by_model"],
        "strategy_counts": class_counts,
        "temperature": SYNTHETIC_TEMPERATURE,
        "state_generator_seed": SEED,
        "features": FEATURES,
        "strategy_rule": {
            "epsilon": EPSILON,
            "undercut": "llm_price < competitor_price - epsilon",
            "match": "abs(llm_price - competitor_price) <= epsilon",
            "overcut": "llm_price > competitor_price + epsilon",
        },
        "prompt_variant_count": len(prompt_hashes),
        "prompt_sha256_set": _hash_text("|".join(prompt_hashes)),
        "validation": validation,
        "files": {
            "raw": "data/raw/llm_behavior_raw.csv",
            "analysis_ready": "results/llm_behavior.csv",
            "failures": "results/llm_behavior_failures.csv",
        },
    }
    MANIFEST_PATH.write_text(
        json.dumps(manifest, indent=2),
        encoding="ascii",
    )
    DATASET_CARD_PATH.write_text(
        "\n".join(
            [
                "# LLM Pricing Behavior Dataset",
                "",
                f"- Version: `{DATASET_VERSION}`",
                f"- Run: `{run_id}`",
                f"- Source: `{data_source}`",
                f"- Models: {', '.join(manifest['models'])}",
                f"- Requested states per model: {n_states_requested}",
                f"- Raw rows: {len(frame)}",
                f"- Valid rows: {len(valid)}",
                f"- Failed rows: {len(failures)}",
                f"- Temperature: {SYNTHETIC_TEMPERATURE}",
                "",
                "## Unit of observation",
                "",
                "One row is one market state paired with one LLM prompt-response.",
                "The same state ids are used across models. The analysis-ready file",
                "contains valid responses only; the raw file retains failures and",
                "invalid outputs.",
                "",
                "## Labels",
                "",
                f"`strategy` is derived from `llm_price` and `competitor_price`",
                f"with epsilon `{EPSILON}` as undercut, match, or overcut.",
                "",
                "## Classification",
                "",
                "### Valid rows by model",
                "",
                "```json",
                json.dumps(validation["valid_rows_by_model"], indent=2),
                "```",
                "",
                "### Strategy counts",
                "",
                "```json",
                json.dumps(class_counts, indent=2),
                "```",
                "",
                "## Intended use",
                "",
                "This dataset is the primary artifact. Regressions, hypothesis tests,",
                "predictive models, SHAP, and calibration are validation layers over",
                "this file, not substitutes for it.",
            ]
        ),
        encoding="ascii",
    )
    return manifest


def run_synthetic_states(
    models: tuple[str, ...] = MODELS,
    n_states: int = N_STATES_TARGET,
    seed: int = SEED,
    output: Path | None = None,
    write_artifacts: bool = True,
) -> pd.DataFrame:
    """Generate clearly labeled synthetic behavior for pipeline validation."""

    rng = np.random.default_rng(seed)
    states = generate_states(n_states=n_states, seed=seed)
    model_intercept = {"llama3:8b": 0.55, "qwen2.5:7b": -0.20}
    run_id = f"synthetic_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
    collected_at = _utc_now()
    rows = []
    for model_name in models:
        for _, state in states.iterrows():
            intercept = model_intercept.get(model_name, 0.0)
            state_score = (
                1.35 * (state["competitor_price"] - 2.0)
                + 0.90 * (state["market_mean_price"] - 2.0)
                - 1.10 * abs(state["own_price"] - state["competitor_price"])
                + 0.35 * (state["round_norm"] - 0.5)
            )
            match_p = float(1.0 / (1.0 + np.exp(-(intercept + state_score))))
            remaining = 1.0 - match_p
            undercut_share = (
                0.55
                if state["own_price"] <= state["competitor_price"]
                else 0.35
            )
            strategy = str(
                rng.choice(
                    ["undercut", "match", "overcut"],
                    p=[
                        remaining * undercut_share,
                        match_p,
                        remaining * (1.0 - undercut_share),
                    ],
                )
            )
            competitor = float(state["competitor_price"])
            if strategy == "match":
                price = competitor + rng.normal(0.0, 0.018)
            elif strategy == "undercut":
                price = competitor - rng.uniform(0.07, 0.24)
            else:
                price = competitor + rng.uniform(0.07, 0.24)
            price = float(np.clip(price, 1.0, 3.0))
            prompt = _prompt(state, model_name)
            raw_output = json.dumps(
                {
                    "price": price,
                    "rationale": f"Synthetic {strategy} decision.",
                }
            )
            rows.append(
                _dataset_row(
                    state=state,
                    model_name=model_name,
                    run_id=run_id,
                    collected_at=collected_at,
                    prompt=prompt,
                    price=price,
                    rationale=f"Synthetic {strategy} decision for validation.",
                    raw_output=raw_output,
                    error="",
                    attempt_count=1,
                    data_source="synthetic_validation",
                )
            )
    frame = pd.DataFrame(rows)
    if output is not None:
        output.parent.mkdir(parents=True, exist_ok=True)
        frame.to_csv(output, index=False)
    if write_artifacts:
        _write_dataset_artifacts(
            frame=frame,
            run_id=run_id,
            data_source="synthetic_validation",
            n_states_requested=n_states,
        )
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n-states", type=int, default=N_STATES_TARGET)
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args()
    frame = run_synthetic_states(
        models=MODELS,
        n_states=10 if args.validate_only else args.n_states,
        output=(
            DATA_DIR / "llm_behavior_validation.csv"
            if args.validate_only
            else None
        ),
        write_artifacts=not args.validate_only,
    )
    print(frame.groupby(["model_name", "strategy"]).size())
    valid = frame.loc[frame["is_valid"]]
    assert set(valid["strategy"]).issubset(set(STRATEGIES))
    assert valid["llm_price"].between(1.0, 3.0).all()
    if args.validate_only:
        assert (valid.groupby("model_name").size() == 10).all()
    else:
        validate_dataset(frame, enforce_sample_size=True)
    print("LLM behavior dataset sanity check passed")


if __name__ == "__main__":
    main()
