"""Tests for the LLM statistical protocol."""

from __future__ import annotations

import json

import numpy as np
import pandas as pd
import pytest

from config import FEATURES, MODELS, RESULTS_DIR
from deferred.llm_track.common import derive_strategy, make_split
from deferred.llm_track.llm_estimation import _fit_terms, _validation_dataset
from deferred.llm_track.llm_hypothesis import holm_correction


def test_strategy_derivation() -> None:
    assert derive_strategy(1.80, 2.00) == "undercut"
    assert derive_strategy(2.00, 2.00) == "match"
    assert derive_strategy(2.20, 2.00) == "overcut"


def test_anchoring_validation_dataset() -> None:
    frame = _validation_dataset()
    coef, _, _ = _fit_terms(frame, ["competitor_price"])
    assert coef[1] == pytest.approx(0.7, abs=0.1)


def test_holm_correction() -> None:
    corrected = holm_correction([0.01, 0.02, 0.5])
    assert corrected[0] == pytest.approx(0.03)
    assert corrected[1] == pytest.approx(0.04)
    assert corrected[2] == pytest.approx(0.5)


def test_pipeline_outputs() -> None:
    required = [
        "llm_behavior.csv",
        "dataset_manifest.json",
        "dataset_card.md",
        "split_manifest.json",
        "estimation_anchoring.csv",
        "estimation_rates.csv",
        "estimation_model_differences.csv",
        "llm_hypothesis_tests.csv",
        "model_comparison.csv",
        "shap_importance.csv",
        "learning_curves.csv",
        "calibration.csv",
        "calibration_summary.json",
        "domain_shift.json",
        "llm_stage_summary.json",
    ]
    for name in required:
        assert (RESULTS_DIR / name).exists(), name

    behavior = pd.read_csv(RESULTS_DIR / "llm_behavior.csv")
    assert set(behavior["model_name"].unique()) == set(MODELS)
    for model in MODELS:
        assert (behavior["model_name"] == model).sum() >= 300

    train, test = make_split(behavior)
    manifest = json.loads(
        (RESULTS_DIR / "split_manifest.json").read_text(encoding="ascii")
    )
    assert manifest["train_rows"] == len(train)
    assert manifest["test_rows"] == len(test)

    effects = pd.read_csv(RESULTS_DIR / "estimation_anchoring.csv")
    beta = effects.loc[
        (effects["specification"] == "multiple")
        & (effects["term"] == "competitor_price")
    ]
    assert len(beta) == len(MODELS)

    tests = pd.read_csv(RESULTS_DIR / "llm_hypothesis_tests.csv")
    assert len(tests) == 5
    assert (tests["p_value_holm"].between(0, 1)).all()

    comparison = pd.read_csv(RESULTS_DIR / "model_comparison.csv")
    assert set(comparison["task"]) == {"classification", "regression"}
    assert len(comparison) == 8

    shap_frame = pd.read_csv(RESULTS_DIR / "shap_importance.csv")
    assert set(shap_frame["feature"]).issuperset(set(FEATURES))
    assert shap_frame["rank"].min() == 1
