"""Five pre-specified hypothesis tests with Holm correction."""

from __future__ import annotations

import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.stats import binomtest, chisquare
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score

from config import (
    FEATURES,
    MODELS,
    N_BOOTSTRAP,
    RESULTS_DIR,
    SCRIPTED_STRATEGY_DISTRIBUTION,
    SEED,
    STRATEGIES,
)
from deferred.llm_track.common import load_behavior, make_split
from deferred.llm_track.llm_estimation import cooperation_rates


def _percentile_interval(values, ci: float = 0.90) -> tuple[float, float]:
    tail = (1.0 - ci) / 2.0
    low, high = np.quantile(np.asarray(values, dtype=float), [tail, 1.0 - tail])
    return float(low), float(high)


def _model_design(frame: pd.DataFrame) -> np.ndarray:
    model_dummy = (frame["model_name"] == MODELS[1]).astype(float).to_numpy()
    matrix = np.column_stack(
        [
            frame["competitor_price"],
            frame["own_price"],
            frame["demand"],
            frame["round_norm"],
            model_dummy,
        ]
    )
    return sm.add_constant(matrix, has_constant="add")


def _fit_anchor(frame: pd.DataFrame) -> float:
    result = sm.OLS(
        frame["llm_price"].to_numpy(dtype=float),
        _model_design(frame),
    ).fit()
    return float(result.params[1])


def permutation_test_coef(
    frame: pd.DataFrame,
    n_permutations: int = 1000,
    seed: int = SEED,
) -> dict:
    """H1: permutation test for the pooled anchoring coefficient."""

    train, _ = make_split(frame)
    observed = _fit_anchor(train)
    rng = np.random.default_rng(seed)
    null = []
    for _ in range(n_permutations):
        permuted = train.copy()
        permuted["competitor_price"] = rng.permutation(
            permuted["competitor_price"].to_numpy()
        )
        null.append(_fit_anchor(permuted))
    p_value = (1 + sum(value >= observed for value in null)) / (
        n_permutations + 1
    )
    samples = []
    for index in range(N_BOOTSTRAP):
        draw = rng.integers(0, len(frame), size=len(frame))
        samples.append(_fit_anchor(frame.iloc[draw].reset_index(drop=True)))
    low, high = _percentile_interval(samples)
    full_effect = _fit_anchor(frame)
    return {
        "hypothesis": "H1",
        "model_name": "pooled",
        "statistic": observed,
        "p_value": p_value,
        "method": "permutation_regression_coefficient",
        "n": len(train),
        "effect_size": full_effect,
        "ci_low": low,
        "ci_high": high,
    }


def binomial_match(frame: pd.DataFrame) -> dict:
    """H2: one-sided binomial test against one-third matching."""

    successes = int((frame["strategy"] == "match").sum())
    n = len(frame)
    test = binomtest(successes, n, p=1 / 3, alternative="greater")
    rates = cooperation_rates(frame)
    match_rows = rates.loc[rates["strategy"] == "match"]
    proportion = successes / n
    return {
        "hypothesis": "H2",
        "model_name": "pooled",
        "statistic": float(test.statistic),
        "p_value": float(test.pvalue),
        "method": "one_sided_binomial",
        "n": n,
        "effect_size": proportion,
        "ci_low": float(match_rows["ci_low"].min()),
        "ci_high": float(match_rows["ci_high"].max()),
    }


def two_proportion_test(
    frame: pd.DataFrame,
    n_permutations: int = 1000,
    seed: int = SEED,
) -> dict:
    """H3: permutation test for model-to-model matching-rate differences."""

    model_a = frame.loc[frame["model_name"] == MODELS[0], "strategy"]
    model_b = frame.loc[frame["model_name"] == MODELS[1], "strategy"]
    observed = float((model_a == "match").mean() - (model_b == "match").mean())
    labels = np.concatenate(
        [
            np.repeat("a", len(model_a)),
            np.repeat("b", len(model_b)),
        ]
    )
    outcomes = np.concatenate(
        [
            (model_a == "match").to_numpy(dtype=int),
            (model_b == "match").to_numpy(dtype=int),
        ]
    )
    rng = np.random.default_rng(seed)
    null = []
    for _ in range(n_permutations):
        shuffled = rng.permutation(labels)
        difference = shuffled.size and (
            outcomes[shuffled == "a"].mean() - outcomes[shuffled == "b"].mean()
        )
        null.append(float(difference))
    p_value = (1 + sum(abs(value) >= abs(observed) for value in null)) / (
        n_permutations + 1
    )

    paired_ids = np.intersect1d(
        frame.loc[frame["model_name"] == MODELS[0], "state_id"].to_numpy(),
        frame.loc[frame["model_name"] == MODELS[1], "state_id"].to_numpy(),
    )
    frame_a = frame.loc[frame["model_name"] == MODELS[0]].set_index("state_id")
    frame_b = frame.loc[frame["model_name"] == MODELS[1]].set_index("state_id")
    diffs = []
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(paired_ids, size=len(paired_ids), replace=True)
        # Duplicate-safe positional lookup for paired state resampling.
        positions = pd.Series(np.arange(len(paired_ids)), index=paired_ids)
        selected_positions = positions.loc[draw].to_numpy()
        a = frame_a.iloc[selected_positions]["strategy"]
        b = frame_b.iloc[selected_positions]["strategy"]
        diffs.append((a == "match").mean() - (b == "match").mean())
    low, high = _percentile_interval(diffs)
    return {
        "hypothesis": "H3",
        "model_name": f"{MODELS[0]} vs {MODELS[1]}",
        "statistic": observed,
        "p_value": p_value,
        "method": "permutation_match_rate_difference",
        "n": len(model_a) + len(model_b),
        "effect_size": observed,
        "ci_low": low,
        "ci_high": high,
    }


def _prediction_matrix(frame: pd.DataFrame) -> np.ndarray:
    model_dummy = (frame["model_name"] == MODELS[1]).astype(float).to_numpy()
    return np.column_stack(
        [frame[feature].to_numpy(dtype=float) for feature in FEATURES]
        + [model_dummy]
    )


def permutation_r2(
    frame: pd.DataFrame,
    n_permutations: int = 1000,
    seed: int = SEED,
) -> dict:
    """H4: permutation test on held-out price-prediction R2."""

    train, test = make_split(frame)
    x_train = _prediction_matrix(train)
    x_test = _prediction_matrix(test)
    y_train = train["llm_price"].to_numpy(dtype=float)
    y_test = test["llm_price"].to_numpy(dtype=float)
    model = Ridge(alpha=1.0).fit(x_train, y_train)
    observed = float(r2_score(y_test, model.predict(x_test)))
    rng = np.random.default_rng(seed)
    null = []
    for _ in range(n_permutations):
        permuted_y = rng.permutation(y_train)
        permuted_model = Ridge(alpha=1.0).fit(x_train, permuted_y)
        null.append(r2_score(y_test, permuted_model.predict(x_test)))
    p_value = (1 + sum(value >= observed for value in null)) / (
        n_permutations + 1
    )
    r2_values = []
    indices = np.arange(len(test))
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(indices, size=len(indices), replace=True)
        r2_values.append(
            r2_score(y_test[draw], model.predict(x_test)[draw])
        )
    low, high = _percentile_interval(r2_values)
    return {
        "hypothesis": "H4",
        "model_name": "pooled",
        "statistic": observed,
        "p_value": float(p_value),
        "method": "permutation_test_r2",
        "n": len(test),
        "effect_size": observed,
        "ci_low": low,
        "ci_high": high,
    }


def distribution_test(
    frame: pd.DataFrame,
    expected: dict[str, float] | None = None,
    seed: int = SEED,
) -> dict:
    """H5: compare pooled strategy distribution with scripted benchmark."""

    expected = expected or SCRIPTED_STRATEGY_DISTRIBUTION
    counts = np.asarray(
        [(frame["strategy"] == strategy).sum() for strategy in STRATEGIES],
        dtype=float,
    )
    expected_counts = np.asarray(
        [expected[strategy] for strategy in STRATEGIES],
        dtype=float,
    )
    expected_counts = expected_counts / expected_counts.sum() * counts.sum()
    test = chisquare(counts, f_exp=expected_counts)
    effect = 0.5 * np.abs(counts / counts.sum() - expected_counts / expected_counts.sum()).sum()

    rng = np.random.default_rng(seed)
    values = []
    for _ in range(N_BOOTSTRAP):
        draw = rng.choice(
            np.arange(len(frame)),
            size=len(frame),
            replace=True,
        )
        sample = frame.iloc[draw]
        sample_counts = np.asarray(
            [
                (sample["strategy"] == strategy).sum()
                for strategy in STRATEGIES
            ],
            dtype=float,
        )
        values.append(
            0.5
            * np.abs(
                sample_counts / sample_counts.sum()
                - expected_counts / expected_counts.sum()
            ).sum()
        )
    low, high = _percentile_interval(values)
    return {
        "hypothesis": "H5",
        "model_name": "pooled",
        "statistic": float(test.statistic),
        "p_value": float(test.pvalue),
        "method": "chi_square_strategy_distribution",
        "n": len(frame),
        "effect_size": float(effect),
        "ci_low": low,
        "ci_high": high,
    }


def holm_correction(p_values) -> np.ndarray:
    """Holm-Bonferroni adjusted p-values."""

    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    for rank, index in enumerate(order):
        candidate = (len(values) - rank) * values[index]
        running = max(running, candidate)
        adjusted[index] = min(1.0, running)
    return adjusted


def run_hypothesis_tests(
    frame: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Run exactly the five pre-specified tests and apply Holm correction."""

    frame = load_behavior() if frame is None else frame
    tests = pd.DataFrame(
        [
            permutation_test_coef(frame),
            binomial_match(frame),
            two_proportion_test(frame),
            permutation_r2(frame),
            distribution_test(frame),
        ]
    )
    tests["p_value_holm"] = holm_correction(tests["p_value"])
    tests = tests[
        [
            "hypothesis",
            "model_name",
            "statistic",
            "p_value",
            "p_value_holm",
            "method",
            "n",
            "effect_size",
            "ci_low",
            "ci_high",
        ]
    ]
    tests.to_csv(RESULTS_DIR / "llm_hypothesis_tests.csv", index=False)
    return tests


def _validation_frame(n: int = 600, seed: int = 31) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows = []
    for model in MODELS:
        competitor = rng.uniform(1.0, 3.0, size=n // 2)
        match_probability = 0.65 if model == MODELS[0] else 0.45
        strategies = rng.choice(
            ["undercut", "match", "overcut"],
            size=n // 2,
            p=[
                (1.0 - match_probability) * 0.55,
                match_probability,
                (1.0 - match_probability) * 0.45,
            ],
        )
        price = competitor.copy()
        price[strategies == "undercut"] -= rng.uniform(
            0.07, 0.24, size=(strategies == "undercut").sum()
        )
        price[strategies == "overcut"] += rng.uniform(
            0.07, 0.24, size=(strategies == "overcut").sum()
        )
        price[strategies == "match"] += rng.normal(
            0.0, 0.015, size=(strategies == "match").sum()
        )
        price = np.clip(price, 1.0, 3.0)
        rows.append(
            pd.DataFrame(
                {
                    "state_id": np.arange(n // 2),
                    "model_name": model,
                    "competitor_price": competitor,
                    "own_price": rng.uniform(1.0, 3.0, size=n // 2),
                    "demand": rng.uniform(0.0, 100.0, size=n // 2),
                    "round_norm": rng.uniform(size=n // 2),
                    "lagged_demand": rng.uniform(0.0, 100.0, size=n // 2),
                    "market_mean_price": rng.uniform(1.0, 3.0, size=n // 2),
                    "llm_price": price,
                    "strategy": strategies,
                }
            )
        )
    return pd.concat(rows, ignore_index=True)


if __name__ == "__main__":
    validation = _validation_frame()
    h1 = permutation_test_coef(validation, n_permutations=200)
    h2 = binomial_match(validation)
    h3 = two_proportion_test(validation, n_permutations=200)
    h4 = permutation_r2(validation, n_permutations=200)
    h5 = distribution_test(
        validation,
        expected={"undercut": 0.10, "match": 0.10, "overcut": 0.80},
    )
    print(pd.DataFrame([h1, h2, h3, h4, h5]).to_string(index=False))
    assert h1["p_value"] < 0.05
    assert h2["p_value"] < 0.05
    assert h3["p_value"] < 0.10
    assert h4["p_value"] < 0.05
    assert h5["p_value"] < 0.05
    print("Hypothesis sanity check passed")
