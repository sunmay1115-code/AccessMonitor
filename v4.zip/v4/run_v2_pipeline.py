"""Calibrate Collusim from LLM observations and run its causal RCT."""

from __future__ import annotations

from config import RESULTS_DIR
from src.collusim.experiments import run_rct
from src.core_sim import build_episode_dataset
from src.detector import train_and_evaluate
from src.llm_track.estimate import estimate_collusim_params


if __name__ == "__main__":
    build_episode_dataset()
    detector = train_and_evaluate()
    print(
        f"Detector AUC={detector['auc']:.3f}, "
        f"FPR@90% recall={detector['fpr_at_tpr90']:.3f}"
    )
    params = estimate_collusim_params()
    print(
        f"Calibrated beta={params['default']['beta']:.3f}, "
        f"sigma={params['default']['sigma']:.3f}"
    )
    frontier = run_rct()
    best = frontier.sort_values("efficiency_ratio", ascending=False).iloc[0]
    print(
        f"Best fix: {best['lever']} at strength {best['strength']:.2f}; "
        f"reduction={best['collusion_reduction']:.3f}, "
        f"welfare_cost={best['welfare_cost']:.3f}"
    )
    print("Collusim v2 pipeline complete.")

